"""Add measured-result commentary and export the already executed report."""
from pathlib import Path
import base64
import json
import zipfile
import nbformat
import pandas as pd
from nbconvert import HTMLExporter

root=Path(__file__).resolve().parents[1]
out=root/'results'
book=nbformat.read(root/'Assignments1.ipynb',as_version=4)
marker='\n\n<!-- measured-observations -->'
for cell in book.cells:
    if cell.cell_type == 'markdown' and marker in cell.source:
        head, rest = cell.source.split(marker, 1)
        # Keep later subquestions when an annotation was inserted in the middle.
        tails = [i for title in ['### 1b.', '### 4b.'] if (i := rest.find(title)) >= 0]
        cell.source = head + ('\n\n' + rest[min(tails):] if tails else '')
book.cells = [c for c in book.cells if not (c.cell_type == 'markdown' and
              c.source.startswith('**Observed point-vote sensitivity.**'))]
def append(prefix,text):
    matches=[c for c in book.cells if c.cell_type=='markdown' and c.source.startswith(prefix)]
    if len(matches)!=1: raise ValueError(f'Expected exactly one cell: {prefix}')
    c=matches[0]
    c.source=c.source.split(marker)[0]+marker+'\n\n**Observed results from this execution.** '+text

lab=pd.read_csv(out/'ex1_lab_metrics.csv').set_index('method')
reg=pd.read_csv(out/'ex1_contamination_summary.csv')
sub=reg[(reg.case=='lower-left positive')&(reg.extra_fraction==.3)].set_index('method')
append('**Interpretation.**',
    f'In Lab 1, OLS estimates slope {lab.loc["OLS","slope"]:.2f}, compared with '
    f'{lab.loc["sklearn RANSAC","slope"]:.2f} for scikit-learn and '
    f'{lab.loc["scratch RANSAC","slope"]:.2f} for our consensus implementation. '
    'Both robust estimates recover the inclined clean relationship, while the different random subsets explain their numerical differences. '
    f'At 30% extra lower-left positive contamination, mean clean-function RMSE is '
    f'{sub.loc["OLS","mean"]:.2f} for OLS, {sub.loc["scratch RANSAC","mean"]:.2f} for scratch RANSAC, '
    f'{sub.loc["sklearn RANSAC","mean"]:.2f} for library RANSAC and '
    f'{sub.loc["point voting","mean"]:.2f} for point voting. '
    'This supports the directional-covariance explanation rather than a claim that every noisy dataset affects OLS equally.')
# The point-vote result follows its sensitivity plot rather than preceding it.
append('### 1c. A consensus',
    'For point voting on the fixed lower-left dataset, q=0.75 gives mean RMSE 1.83 and retains on average 33 appended observations. '
    'At q=0.95 the mean RMSE rises to 51.64 and 224 appended observations remain. '
    'At q=0.25 the selected x-span is only 1.28, compared with 4.41 at q=0.75: aggressive voting also sacrifices predictor coverage. '
    'These values describe this sensitivity experiment; they do not establish an optimal q for arbitrary contamination.')
location=pd.read_csv(out/'ex2_location_comparison.csv').set_index('method')
single=pd.read_csv(out/'ex2_single_cloud_raw.csv')
cluster=pd.read_csv(out/'ex2_clustering_raw.csv')
s=single[(single.distance==10)&(single.fraction==.4)].groupby('method').population_error.mean()
c=cluster[(cluster.distance==10)&(cluster.fraction==.4)].groupby('method').center_error.mean()
append('**Comparison and limits.**',
    f'On the 100+10 point cloud, population-center error is {location.loc["Mean","population_error"]:.3f} '
    f'for the all-data mean, {location.loc["RANSAC","population_error"]:.3f} for RANSAC, '
    f'{location.loc["One-class SVM","population_error"]:.3f} for SVM and '
    f'{location.loc["Synthetic","population_error"]:.3f} for the synthetic prototype. '
    'For 20% total contamination in the sensitivity study, (0.1,0.8) and the four-step schedule both give mean error 0.101; '
    'a fifth intermediate step gives 0.101 as well. Ending at 0.9 increases error to 0.682, and ending at 1.0 to 1.404. '
    'Thus the final fraction matters much more than additional steps in this particular study. '
    f'With distance 10 and 40% contamination, single-cloud errors are {s["Mean"]:.2f} (mean), '
    f'{s["RANSAC"]:.2f} (RANSAC), {s["One-class SVM"]:.2f} (SVM) and {s["Synthetic"]:.2f} (synthetic). '
    f'Yet full-clustering matched-center errors range from {c.min():.2f} to {c.max():.2f}. '
    'The large error bars and poor full-clustering scores reveal initialization/assignment failures shared across estimators. '
    'We cannot infer from good single-cloud location recovery that robust clustering is solved. No SVM empty-acceptance fallback occurred in these runs.')
ndf=pd.read_csv(out/'ex3_nn_bias_variance.csv')
r=ndf[(ndf.d==10)&(ndf.function=='Radial')].iloc[0]
g=ndf[(ndf.d==10)&(ndf.function=='Cubic')].iloc[0]
ratios=pd.read_csv(out/'ex3_epe_ratio.csv')
append('**Discussion.** The geometric',
    f'At d=10 the mean nearest-neighbor radius is {r.mean_radius:.3f}; '
    f'{r["Pr_radius_above_0.5"]:.1%} of nearest neighbors are farther than 0.5 from zero. '
    f'The radial MSE is {r.MSE:.5f}, comprising squared bias {r.bias2:.5f} and variance {r.variance:.5f}. '
    f'For the cubic function, MSE is {g.MSE:.5f}, with variance {g.variance:.5f} and squared bias {g.bias2:.5f}. '
    f'The integrated-noise EPE ratio for the linear model rises from '
    f'{ratios[(ratios.d==1)&(ratios.function=="Linear")].iloc[0].ratio:.3f} at d=1 to '
    f'{ratios[(ratios.d==10)&(ratios.function=="Linear")].iloc[0].ratio:.3f} at d=10; '
    f'the cubic ratios are {ratios[(ratios.d==1)&(ratios.function=="Cubic")].iloc[0].ratio:.3f} and '
    f'{ratios[(ratios.d==10)&(ratios.function=="Cubic")].iloc[0].ratio:.3f}. '
    'Both reproduce the trends and scale of the textbook figures, with independently chosen seeds.')
meta=json.loads((out/'ex4_model_metadata.json').read_text())
append('**Why a larger training',
    'The mean development holdout accuracy is 0.9811 at 75% training, compared with an empirical maximum 0.9859 at 95% training. '
    'However, the 95% split has only 23 test observations and SD 0.0249, compared with 114 observations and SD 0.0098 at 75%. '
    f'Validation selects C={meta["C"]:g}. The delivered pipeline correctly predicts 109 of 114 locked-test observations '
    f'(accuracy {meta["test_accuracy"]:.4f}; Wilson interval '
    f'{meta["test_Wilson_interval"][0]:.4f}–{meta["test_Wilson_interval"][1]:.4f}). '
    'This is lower than the development averages, illustrating finite-sample and partition variability. '
    'The test is kept as reported; it is not used to retune C.')
append('**Discussion.** Early estimates',
    'Across 30 runs, online accuracy increases from a first-pair mean of 0.9367 to a final mean of 0.9767 in the easy case, '
    'and from 0.5644 to 0.6893 in the hard case. The corresponding Bayes accuracies are 0.9772 and 0.6915. '
    'Final online and batch-centroid means are identical in both cases. The two mean vectors occupy 32 bytes of numerical storage in 2-D, '
    'excluding Python object and counter overhead; this remains independent of stream length.')
dim=pd.read_csv(out/'ex6_dimension_summary.csv')
kn=dim[dim.method=='kNN'].set_index('d'); tree=dim[dim.method=='Tree'].set_index('d')
nested=pd.read_csv(out/'ex6_nested_raw.csv')
avg=nested.groupby('method')[['test_accuracy','test_regularity']].mean()
append('**Interpretation of the factors.**',
    f'After nested tuning, mean kNN accuracy falls from {kn.loc[1,"test_accuracy"]:.3f} at d=1 '
    f'to {kn.loc[100,"test_accuracy"]:.3f} at d=100; tree accuracy changes from '
    f'{tree.loc[1,"test_accuracy"]:.3f} to {tree.loc[100,"test_accuracy"]:.3f}. '
    f'The corresponding kNN regularity falls from {kn.loc[1,"test_regularity"]:.3f} to '
    f'{kn.loc[100,"test_regularity"]:.3f}, and tree regularity from '
    f'{tree.loc[1,"test_regularity"]:.3f} to {tree.loc[100,"test_regularity"]:.3f}. '
    'The tree retains accuracy better because the signal is concentrated on one axis, while the neighborhood geometry is diluted for both metrics. '
    f'Averaged over the full requested grid, selected kNN test accuracy is {avg.loc["kNN","test_accuracy"]:.3f} '
    f'and selected tree accuracy {avg.loc["Tree","test_accuracy"]:.3f}; these marginal averages are summaries of this design, not universal method rankings. '
    'The even-k dips in the fixed-k accuracy plot are consistent with deterministic class-0 tie breaking in a balanced problem. '
    'The constant-prediction example explicitly gives accuracy 0.5 but regularity 1, confirming that the two measures are not interchangeable.')
# Place measured observations beside the relevant subquestion, rather than after a later one.
for cell in book.cells:
    if cell.cell_type != 'markdown' or marker not in cell.source:
        continue
    main, note = cell.source.split(marker, 1)
    if main.startswith('**Interpretation.**') and '### 1b.' in main:
        head, tail = main.split('### 1b.', 1)
        cell.source = head.rstrip() + marker + note + '\n\n### 1b.' + tail
    elif main.startswith('**Why a larger training') and '### 4b.' in main:
        head, tail = main.split('### 4b.', 1)
        cell.source = head.rstrip() + marker + note + '\n\n### 4b.' + tail
# The point-vote sensitivity belongs between its plot and Exercise 1c.
for index, cell in enumerate(book.cells):
    if cell.cell_type == 'markdown' and cell.source.startswith('### 1c. A consensus') and marker in cell.source:
        main, note = cell.source.split(marker, 1)
        cell.source = main
        previous = nbformat.v4.new_markdown_cell(note.strip().replace(
            '**Observed results from this execution.**', '**Observed point-vote sensitivity.**', 1))
        book.cells.insert(index, previous)
        break
# Resolve the missing illustration in the supplied template with an embedded generated illustration.
for cell in book.cells:
    if cell.cell_type!='markdown': continue
    cell.source=cell.source.replace('their actual residual is reported rather than falsely guaranteeing separation',
        'their residuals determine consensus membership rather than guaranteeing separation')
    if './cloud-of-points-outliers.png' in cell.source:
        cell.source=cell.source.replace('<img src="./cloud-of-points-outliers.png" alt="Drawing" style="width: 500px;"/>',
            '![Recreated Gaussian point-cloud illustration](attachment:cloud-of-points-outliers.png)\n\n'
            '*Illustration recreated from the specified distributions; the supplied folder did not include the original image.*')
        cell['attachments']={'cloud-of-points-outliers.png':{
            'image/png':base64.b64encode((out/'ex1_robust_location.png').read_bytes()).decode()}}
# LLM disclosure is the final, separately titled cell as the assignment requests.
last=book.cells[-1]
if '\n### Use of LLMs\n' in last.source:
    main,disclosure=last.source.split('\n### Use of LLMs\n',1)
    last.source=main.rstrip()
    book.cells.append(nbformat.v4.new_markdown_cell('## Use of LLMs\n'+disclosure))
nbformat.validate(book)
assert all(c.execution_count is not None for c in book.cells if c.cell_type=='code')
assert not any(o.output_type=='error' for c in book.cells if c.cell_type=='code' for o in c.outputs)
nbformat.write(book,root/'Assignments1.ipynb')
exporter=HTMLExporter()
exporter.embed_images=True
html,_=exporter.from_notebook_node(book)
(root/'Assignments1.html').write_text(html)
# Archive only reviewable deliverables, never the virtual environment.
paths=[root/'Assignments1.ipynb',root/'Assignments1.html',root/'README.md',
       root/'STUDY_GUIDE_zh.md',root/'requirements.txt',root/'scripts'/'execute_notebook.py',root/'scripts'/'finalize_report.py']
paths+=sorted(p for p in out.iterdir() if p.is_file())
with zipfile.ZipFile(root/'submission_Fang_Huang.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in paths: archive.write(path,path.relative_to(root))
with zipfile.ZipFile(root/'submission_Fang_Huang.zip') as archive:
    assert archive.testzip() is None
print(f'Finalized {len(book.cells)} cells; {len(paths)} archived files.')
print('Notebook, HTML and submission_Fang_Huang.zip ready.')
