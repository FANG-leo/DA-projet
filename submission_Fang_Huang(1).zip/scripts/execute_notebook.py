"""Execute the report in a fresh kernel; save partial work if a cell fails."""
from pathlib import Path
import sys
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager
root=Path(__file__).resolve().parents[1]
nb=nbformat.read(root/'Assignments1.ipynb',as_version=4)
# Use this environment directly; no global kernelspec installation is necessary.
km=KernelManager(kernel_name='python3')
km.kernel_spec.argv=[sys.executable,'-m','ipykernel_launcher','-f','{connection_file}']
client=NotebookClient(nb,timeout=3600,kernel_manager=km,resources={'metadata':{'path':str(root)}})
client.on_cell_start=lambda cell,cell_index: print(f'Cell {cell_index+1}/{len(nb.cells)}: '+''.join(cell.source).splitlines()[0][:100],flush=True)
try:
    client.execute()
finally:
    nbformat.write(nb,root/'Assignments1.ipynb')
print('Execution complete',flush=True)
