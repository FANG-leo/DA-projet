# DA Assignment 1 — Fang & Huang（方、黄）

主报告：`Assignments1.ipynb`。原始作业保存在 `Assignments1_original.ipynb`，本地 Lab 1 保持原样。

报告按题目顺序完成六道题，使用英文说明、LaTeX 推导、实际运行的代码与输出。`results/` 保存原始实验数据、汇总表、高清图、运行记录及第 4 题训练完成的模型。无需下载外部数据即可运行所有实验。

## 查看与重新运行

在 VS Code 或 Jupyter 中打开 `Assignments1.ipynb`；选择本目录 `.venv/bin/python` 作为 Python 环境，从头运行所有单元格。Notebook 已保存运行结果，不运行也可阅读。

在其他电脑重建环境：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/execute_notebook.py
```

本项目的完整依赖版本记录在 `requirements.txt`。需 Python 3.12；其他 Python 版本可能需要调整依赖版本。执行脚本使用该 Python 环境启动内核，无需全局注册 Jupyter 内核。受限环境需允许 Jupyter 通过本机端口通信；这不涉及上传作业。

`Assignments1.html` 为便于查看的静态报告。公式渲染可能需要浏览器加载 MathJax；Notebook 为正式主文件。

## 内容与结果文件

| 作业 | 完成内容 | 结果前缀 |
|---|---|---|
| 1 | 自写 RANSAC、Lab 1 复现、三种异常点实验、模型对点投票、鲁棒中心、可插拔聚类、通用伪代码 | `ex1_` |
| 2 | One-class SVM、精确 medoid 与逐步邻域原型、参数敏感性、污染比例和距离的聚类比较、时间成本 | `ex2_` |
| 3 | ESL 图 2.6–2.9、偏差方差分解、误差比、Monte Carlo 误差与噪声积分验证 | `ex3_` |
| 4 | 0%–100% 划分比例、训练/验证/测试隔离、调参、保存模型、时间序列验证伪代码 | `ex4_` |
| 5 | 常数流长度内存的在线线性分类器、困难/简单案例、在线与批量一致性检验 | `ex5_` |
| 6 | 全参数网格、10 次重复、直接留出与内层十折验证、嵌套调参后的独立测试、Regularity 的局限 | `ex6_` |

第 6 题包含 960 组独立数据、38,400 条固定参数评估记录和 1,920 条选模后测试记录。决策树不依赖 kNN 的 k，相关表格明确处理这一重复轴。全部实验使用显式随机种子；不以预先保存的 CSV 替代计算。

`ex4_final_classifier.joblib` 保存标准化和逻辑回归的完整 pipeline，特征顺序及软件版本见 `ex4_model_metadata.json`。示例：

```python
import joblib
model = joblib.load('results/ex4_final_classifier.joblib')
predictions = model.predict(X_new)  # X_new 的 30 列须按 metadata 中的顺序
```

## 提交前由作者完成

- 标题已使用用户提供的姓氏 Fang & Huang（方、黄）；邮件中补全两人的实际姓名和真实分工。
- 作业要求学生理解并能口头解释结果：请自行运行、核对并阅读 `STUDY_GUIDE_zh.md`。
- Notebook 最后准确披露了 Codex 对设计、实现、文字和执行的广泛参与。根据你们实际进行的修改和独立运行更新该说明，保留真实披露。
- 按原题要求用邮件提交单份 notebook 和所需附属文件；本项目未发送任何邮件。

`submission_Fang_Huang.zip` 是便于携带的提交候选包，包含 notebook、静态报告、依赖说明、复现脚本和结果；不包含 `.venv`、本地 Lab 的原始文件或重复的空白作业。正式成绩依赖实验质量、你们自己的工作与理解，无法预先保证。
